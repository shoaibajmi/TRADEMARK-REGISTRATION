<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="tm-step-container">
    <h2>Step 4 — Confirmation</h2>

    <div id="tm-summary-view">
        <!-- JS will render summary from sessionStorage -->
    </div>

    <!-- <button id="tm-final-submit" class="tm-btn-primary">
        Submit & Proceed to Payment →
    </button> -->
    <button id="tm-submit-order" class="tm-button-primary">
    Proceed to Checkout
</button>

</div>
