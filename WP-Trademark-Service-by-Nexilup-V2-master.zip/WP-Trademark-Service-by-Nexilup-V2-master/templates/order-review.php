<?php
if (!defined('ABSPATH')) exit;

get_header();
echo do_shortcode('[tm_service_form]');
get_footer();
