<?php
if (!defined('ABSPATH')) exit;

// Include the trademarks router
include WP_TMS_NEXILUP_PLUGIN_PATH . 'includes/admin-trademark-router.php';