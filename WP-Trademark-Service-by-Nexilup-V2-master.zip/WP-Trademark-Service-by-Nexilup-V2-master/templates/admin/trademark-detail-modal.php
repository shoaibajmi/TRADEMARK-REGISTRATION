<div class="tm-admin-modal-overlay">

    <div class="tm-admin-modal-box">

        <button class="tm-admin-modal-close">&times;</button>

        <h2 class="tm-admin-modal-title">Trademark Details</h2>

        <div id="tm-admin-modal-content">
            Loading…
        </div>

    </div>

</div>
