<?php
if (!defined('ABSPATH')) exit;

get_header();

// You already have this template in your plugin
include WP_TMS_NEXILUP_PLUGIN_PATH . 'templates/frontend/my-trademarks.php';

get_footer();
